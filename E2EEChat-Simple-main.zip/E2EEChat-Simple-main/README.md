# E2EEChat-Simple
11~14주차 과제: E2EE 채팅 프로그램 

* [패키지 다운로드](https://github.com/CNUCSE-InformationSecurity-2022-Fall/E2EEChat-Simple/releases/tag/assignment)
* 과제 수행을 위한 파이썬 스크립트는 압축 파일 내에 있습니다.


![image](https://user-images.githubusercontent.com/13935811/203414191-777a2ef0-bde4-4c43-b89f-33408045f93e.png)
